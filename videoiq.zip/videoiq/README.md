# VideoIQ — AI-Powered Video Insights Platform

> Turn any recording into searchable, queryable knowledge in minutes.

---

## What it does

Upload a video (training session, tech talk, onboarding recording, team meeting, sales call) and VideoIQ will:

- **Transcribe** it locally with Whisper (no audio ever leaves your machine)
- **Analyse** with Claude AI to extract summaries, key points, action items, chapters, smart clips, quiz questions, and insights
- **Let you query** the recording in natural language: *"Who owns the Kafka action item?"*
- **Export** as Markdown, JSON, or plain text

---

## Quick Start (5 minutes)

### 1. Prerequisites

| Tool | Install |
|------|---------|
| Python 3.9+ | [python.org](https://python.org) |
| FFmpeg | macOS: `brew install ffmpeg` · Ubuntu: `sudo apt install ffmpeg` · Windows: [ffmpeg.org](https://ffmpeg.org/download.html) |
| Anthropic API key | [console.anthropic.com](https://console.anthropic.com) (free tier available) |

### 2. Get the code

Download and unzip `videoiq.zip`, then open a terminal in the `videoiq/` folder.

### 3. Add your API key

```bash
cp .env.example .env
# Open .env in any text editor and paste your ANTHROPIC_API_KEY
```

### 4. Run the setup script (installs everything + starts server)

```bash
python start.py
```

That's it. Open **http://localhost:8000** in your browser.

---

## Manual setup (if start.py fails)

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Pre-download Whisper model
python -c "import whisper; whisper.load_model('base')"

# Start server
python app.py
```

---

## Configuration (`.env`)

```env
# Required for AI features
ANTHROPIC_API_KEY=sk-ant-...

# Whisper model: tiny | base | small | medium | large
# tiny  = fastest (~1 GB RAM, lower accuracy)
# base  = good balance (default)
# small = better accuracy, ~2 GB RAM
# large = best quality, ~10 GB RAM, slow on CPU
WHISPER_MODEL=base
```

> **No API key?** The tool still works — you get the full transcript and Whisper processing. AI summaries, action items, and Q&A will show a placeholder message.

---

## Use Cases

| Mode | What AI extracts |
|------|-----------------|
| 🏫 Training & L&D | Learning objectives, key concepts, 5 quiz questions |
| 🔬 Tech Talk | Architecture decisions, tech stack, code patterns |
| 🤝 Onboarding | SOPs, tools, key contacts, process steps |
| 📋 Team Meeting | Decisions, action items + owners + deadlines, risks |
| 🎯 Sales Call | Objections, product feedback, commitments, next steps |
| 🧠 Research Interview | Themes, sentiment, notable quotes, patterns |

---

## API Endpoints

The backend exposes a REST API you can also use directly:

```
POST /api/upload          Upload video + use_case param
GET  /api/status/{id}     Poll processing progress
GET  /api/results/{id}    Get full analysis JSON
POST /api/query           Ask a question about a video
GET  /api/download/{id}/{fmt}   Export (json|markdown|txt)
GET  /api/jobs            List all processed videos
GET  /api/frame/{id}/{n}  Get extracted frame image
```

---

## Project Structure

```
videoiq/
├── app.py           ← FastAPI backend (pipeline + API routes)
├── start.py         ← One-shot setup & launch script
├── requirements.txt
├── .env.example     → copy to .env
├── static/
│   └── index.html   ← Full frontend (single HTML file)
├── uploads/         ← Uploaded videos (auto-created)
├── outputs/         ← Analysis results, frames, exports (auto-created)
└── temp/            ← Temporary audio/frame files (auto-cleaned)
```

---

## Pipeline (LangGraph-style)

```
Upload
  ↓ Validate & metadata (OpenCV)
  ↓ Extract audio (FFmpeg)
  ↓ Transcribe (Whisper local)
  ↓ Extract frames (OpenCV, 1/30s)
  ↓ AI analysis (Claude)
      → Summary (TL;DR + full)
      → Key points
      → Topics
      → Action items + owners
      → Auto chapters
      → Smart clips
      → AI insights
      → Quiz questions (training mode)
  ↓ Save results.json + insights.md + transcript.txt
  ↓ Clean temp files
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `FFmpeg not found` | Install FFmpeg and ensure it's on your PATH |
| `Whisper too slow` | Set `WHISPER_MODEL=tiny` in `.env` |
| `AI features disabled` | Add `ANTHROPIC_API_KEY` to `.env` |
| `Port 8000 in use` | Change port: `uvicorn app:app --port 8001` |
| Large video times out | Use `WHISPER_MODEL=tiny` or a GPU machine |
| `pip install` fails | Try `pip install -r requirements.txt --break-system-packages` |

---

## Tech Stack

- **Backend**: FastAPI + Uvicorn
- **Transcription**: OpenAI Whisper (100% local)
- **AI Analysis**: Anthropic Claude (claude-sonnet-4-6)
- **Video processing**: FFmpeg + OpenCV
- **Frontend**: Vanilla HTML/CSS/JS (zero dependencies)
- **Export**: JSON, Markdown, plain text

---

*Built for innovation events — deploy anywhere Python runs.*
