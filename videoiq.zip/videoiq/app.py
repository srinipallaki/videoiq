"""
VideoIQ - AI-Powered Video Insights Platform
Main application entry point
"""

import os
import json
import time
import uuid
import base64
import shutil
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional

import cv2
import whisper
from anthropic import Anthropic
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
BASE_DIR     = Path(__file__).parent
UPLOADS_DIR  = BASE_DIR / "uploads"
OUTPUTS_DIR  = BASE_DIR / "outputs"
TEMP_DIR     = BASE_DIR / "temp"
STATIC_DIR   = BASE_DIR / "static"

for d in [UPLOADS_DIR, OUTPUTS_DIR, TEMP_DIR, STATIC_DIR]:
    d.mkdir(parents=True, exist_ok=True)

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
WHISPER_MODEL_SIZE = os.environ.get("WHISPER_MODEL", "base")
SUPPORTED_FORMATS = {"mp4", "mov", "webm", "mkv", "avi"}
MAX_FILE_MB = 500

# Global state
jobs: dict = {}          # job_id -> status dict
whisper_model = None     # loaded on first use

# ─────────────────────────────────────────────
# FASTAPI APP
# ─────────────────────────────────────────────
app = FastAPI(title="VideoIQ", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

# ─────────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────────
class QueryRequest(BaseModel):
    job_id: str
    question: str

class ExportRequest(BaseModel):
    job_id: str
    format: str  # "json" | "markdown" | "txt"

# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def get_whisper():
    global whisper_model
    if whisper_model is None:
        print(f"[VideoIQ] Loading Whisper ({WHISPER_MODEL_SIZE})…")
        whisper_model = whisper.load_model(WHISPER_MODEL_SIZE)
        print("[VideoIQ] Whisper ready.")
    return whisper_model

def fmt_time(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

def set_step(job_id: str, step: str, pct: int):
    if job_id in jobs:
        jobs[job_id]["current_step"] = step
        jobs[job_id]["progress"]     = pct

def claude_generate(prompt: str, system: str = "", max_tokens: int = 2000) -> str:
    """Call Claude API; falls back to a placeholder if no key configured."""
    if not ANTHROPIC_API_KEY:
        return "[Set ANTHROPIC_API_KEY in your .env to enable AI-powered insights]"
    client = Anthropic(api_key=ANTHROPIC_API_KEY)
    msgs = [{"role": "user", "content": prompt}]
    kwargs = {"model": "claude-sonnet-4-6", "max_tokens": max_tokens, "messages": msgs}
    if system:
        kwargs["system"] = system
    resp = client.messages.create(**kwargs)
    return resp.content[0].text.strip()

# ─────────────────────────────────────────────
# PIPELINE
# ─────────────────────────────────────────────
def run_pipeline(job_id: str, video_path: Path, use_case: str):
    """Full LangGraph-style pipeline running in a background thread."""
    try:
        jobs[job_id]["status"] = "processing"
        out_dir = OUTPUTS_DIR / job_id
        out_dir.mkdir(parents=True, exist_ok=True)
        tmp_dir = TEMP_DIR / job_id
        tmp_dir.mkdir(parents=True, exist_ok=True)

        # ── STEP 1: Metadata ────────────────────────────────────
        set_step(job_id, "Extracting video metadata…", 5)
        cap = cv2.VideoCapture(str(video_path))
        fps        = cap.get(cv2.CAP_PROP_FPS) or 25
        width      = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height     = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration   = total_frames / fps if fps else 0
        cap.release()

        metadata = {
            "filename":         video_path.name,
            "duration_seconds": round(duration, 2),
            "duration_fmt":     fmt_time(duration),
            "fps":              round(fps, 2),
            "resolution":       f"{width}x{height}",
            "file_size_mb":     round(video_path.stat().st_size / 1_048_576, 2),
            "use_case":         use_case,
            "analyzed_at":      datetime.now().isoformat(),
        }
        jobs[job_id]["metadata"] = metadata

        # ── STEP 2: Extract audio ───────────────────────────────
        set_step(job_id, "Extracting audio track…", 15)
        audio_path = tmp_dir / "audio.mp3"
        cmd = ["ffmpeg", "-y", "-i", str(video_path),
               "-q:a", "5", "-map", "a", str(audio_path)]
        result = subprocess.run(cmd, capture_output=True)
        if result.returncode != 0 or not audio_path.exists():
            raise RuntimeError(f"FFmpeg failed: {result.stderr.decode()[:300]}")

        # ── STEP 3: Transcribe ──────────────────────────────────
        set_step(job_id, "Transcribing audio with Whisper…", 25)
        model = get_whisper()
        raw   = model.transcribe(str(audio_path), verbose=False)
        transcript_text = raw["text"].strip()
        language        = raw.get("language", "en")

        # Build timestamped segments
        segments = []
        for seg in raw.get("segments", []):
            segments.append({
                "start":   round(seg["start"], 1),
                "end":     round(seg["end"],   1),
                "start_fmt": fmt_time(seg["start"]),
                "text":    seg["text"].strip(),
            })

        # Save raw transcript
        transcript_file = out_dir / "transcript.txt"
        transcript_file.write_text(transcript_text, encoding="utf-8")

        jobs[job_id]["transcript"]      = transcript_text
        jobs[job_id]["segments"]        = segments
        jobs[job_id]["language"]        = language

        # ── STEP 4: Extract frames ──────────────────────────────
        set_step(job_id, "Extracting key frames…", 45)
        frames_dir = out_dir / "frames"
        frames_dir.mkdir(exist_ok=True)
        frame_interval = max(1, int(fps * 30))   # 1 frame every 30s
        cap   = cv2.VideoCapture(str(video_path))
        count = 0
        saved = 0
        frame_paths = []
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            if count % frame_interval == 0:
                fname = frames_dir / f"frame_{saved:03d}.jpg"
                small = cv2.resize(frame, (640, 360))
                cv2.imwrite(str(fname), small, [cv2.IMWRITE_JPEG_QUALITY, 75])
                frame_paths.append(str(fname))
                saved += 1
            count += 1
        cap.release()
        jobs[job_id]["frame_count"] = saved

        # ── STEP 5: AI Analysis ─────────────────────────────────
        set_step(job_id, "Analysing with Claude AI…", 60)

        use_case_instructions = {
            "training":  "Focus on: learning objectives, key concepts taught, recommended quiz questions (5), skills demonstrated.",
            "tech_talk": "Focus on: architecture decisions, tech stack mentioned, code patterns, action items for engineers.",
            "onboarding":"Focus on: processes explained, tools introduced, key contacts mentioned, SOP steps.",
            "meeting":   "Focus on: decisions made, action items with owners and deadlines, blockers raised, risks.",
            "sales":     "Focus on: objections raised, product feedback, commitments made, next steps.",
            "research":  "Focus on: key themes, notable quotes, participant sentiments, patterns across topics.",
        }
        uc_hint = use_case_instructions.get(use_case, "Provide a comprehensive analysis.")

        system_prompt = f"""You are VideoIQ, an AI that converts video transcripts into structured knowledge.
Use case context: {use_case} — {uc_hint}
Always respond in valid JSON only. No markdown fences, no prose outside JSON."""

        analysis_prompt = f"""Analyse this video transcript and return a JSON object with EXACTLY these keys:

{{
  "short_summary": "2-3 sentence TL;DR",
  "medium_summary": "Full paragraph (5-7 sentences)",
  "key_points": ["point 1", "point 2", "point 3", "point 4", "point 5"],
  "topics": ["topic1", "topic2", "topic3", "topic4", "topic5"],
  "action_items": [
    {{"text": "action description", "owner": "Person/Team", "due": "timeframe or 'TBD'", "timestamp": "MM:SS"}}
  ],
  "chapters": [
    {{"title": "Chapter name", "start_fmt": "MM:SS", "end_fmt": "MM:SS", "summary": "1-sentence summary"}}
  ],
  "insights": [
    {{"type": "insight|action|risk|bookmark", "text": "insight text", "timestamp": "MM:SS or null"}}
  ],
  "quiz_questions": [
    {{"question": "...", "answer": "..."}}
  ],
  "smart_clips": [
    {{"title": "clip title", "start_fmt": "MM:SS", "end_fmt": "MM:SS", "reason": "why this is valuable"}}
  ]
}}

TRANSCRIPT:
{transcript_text[:8000]}

Return only the JSON object."""

        raw_json = claude_generate(analysis_prompt, system=system_prompt, max_tokens=3000)

        # Clean & parse JSON
        try:
            clean = raw_json.strip()
            if clean.startswith("```"):
                clean = clean.split("```")[1]
                if clean.startswith("json"):
                    clean = clean[4:]
            analysis = json.loads(clean)
        except Exception:
            analysis = {
                "short_summary":  transcript_text[:200],
                "medium_summary": transcript_text[:600],
                "key_points":     ["See full transcript for details"],
                "topics":         ["General"],
                "action_items":   [],
                "chapters":       [],
                "insights":       [],
                "quiz_questions": [],
                "smart_clips":    [],
            }

        jobs[job_id]["analysis"] = analysis

        # ── STEP 6: Save results ────────────────────────────────
        set_step(job_id, "Building search index & saving…", 85)

        full_result = {
            "job_id":     job_id,
            "metadata":   metadata,
            "transcript": transcript_text,
            "segments":   segments,
            "language":   language,
            "analysis":   analysis,
        }
        (out_dir / "results.json").write_text(
            json.dumps(full_result, indent=2, ensure_ascii=False), encoding="utf-8"
        )

        # Markdown export
        md = _build_markdown(full_result)
        (out_dir / "insights.md").write_text(md, encoding="utf-8")

        # ── DONE ────────────────────────────────────────────────
        set_step(job_id, "Complete!", 100)
        jobs[job_id]["status"]      = "completed"
        jobs[job_id]["output_dir"]  = str(out_dir)
        shutil.rmtree(tmp_dir, ignore_errors=True)

    except Exception as exc:
        import traceback
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["error"]  = str(exc)
        jobs[job_id]["trace"]  = traceback.format_exc()
        print(f"[VideoIQ] Pipeline error for {job_id}: {exc}")

def _build_markdown(result: dict) -> str:
    meta = result["metadata"]
    ana  = result["analysis"]
    lines = [
        f"# {meta['filename']} — VideoIQ Insights",
        f"**Duration:** {meta['duration_fmt']}  |  **Language:** {result['language']}  |  **Use case:** {meta['use_case']}",
        f"\n---\n",
        f"## TL;DR\n{ana.get('short_summary','')}",
        f"\n## Summary\n{ana.get('medium_summary','')}",
        "\n## Key Points",
    ]
    for i, p in enumerate(ana.get("key_points", []), 1):
        lines.append(f"{i}. {p}")
    lines.append("\n## Topics\n" + "  ".join(f"`{t}`" for t in ana.get("topics", [])))

    if ana.get("action_items"):
        lines.append("\n## Action Items\n| # | Action | Owner | Due | Timestamp |")
        lines.append("|---|--------|-------|-----|-----------|")
        for i, a in enumerate(ana["action_items"], 1):
            lines.append(f"| {i} | {a.get('text','')} | {a.get('owner','TBD')} | {a.get('due','TBD')} | {a.get('timestamp','')} |")

    if ana.get("chapters"):
        lines.append("\n## Chapters")
        for c in ana["chapters"]:
            lines.append(f"- **{c.get('start_fmt','')} – {c.get('end_fmt','')}** {c.get('title','')} — {c.get('summary','')}")

    if ana.get("quiz_questions"):
        lines.append("\n## Quiz / Learning Check")
        for i, q in enumerate(ana["quiz_questions"], 1):
            lines.append(f"\n**Q{i}.** {q.get('question','')}\n> {q.get('answer','')}")

    lines.append("\n---\n*Generated by VideoIQ*")
    return "\n".join(lines)

# ─────────────────────────────────────────────
# API ROUTES
# ─────────────────────────────────────────────
@app.post("/api/upload")
async def upload_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    use_case: str = "meeting",
):
    ext = Path(file.filename).suffix.lstrip(".").lower()
    if ext not in SUPPORTED_FORMATS:
        raise HTTPException(400, f"Unsupported format: .{ext}")

    size_mb = 0
    job_id   = str(uuid.uuid4())[:8]
    dest     = UPLOADS_DIR / f"{job_id}_{file.filename}"

    with open(dest, "wb") as f:
        while chunk := await file.read(1_048_576):
            size_mb += len(chunk) / 1_048_576
            if size_mb > MAX_FILE_MB:
                dest.unlink(missing_ok=True)
                raise HTTPException(413, "File exceeds 500 MB limit")
            f.write(chunk)

    jobs[job_id] = {
        "status":       "queued",
        "filename":     file.filename,
        "use_case":     use_case,
        "progress":     0,
        "current_step": "Queued…",
        "created_at":   datetime.now().isoformat(),
    }
    background_tasks.add_task(run_pipeline, job_id, dest, use_case)
    return {"job_id": job_id}

@app.get("/api/status/{job_id}")
def get_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    j = jobs[job_id]
    return {
        "job_id":       job_id,
        "status":       j["status"],
        "progress":     j.get("progress", 0),
        "current_step": j.get("current_step", ""),
        "filename":     j.get("filename", ""),
        "use_case":     j.get("use_case", ""),
        "error":        j.get("error"),
    }

@app.get("/api/results/{job_id}")
def get_results(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    j = jobs[job_id]
    if j["status"] != "completed":
        raise HTTPException(400, f"Job status: {j['status']}")
    return {
        "job_id":     job_id,
        "metadata":   j.get("metadata", {}),
        "transcript": j.get("transcript", ""),
        "segments":   j.get("segments", []),
        "language":   j.get("language", "en"),
        "analysis":   j.get("analysis", {}),
        "frame_count":j.get("frame_count", 0),
    }

@app.post("/api/query")
def query_video(req: QueryRequest):
    if req.job_id not in jobs:
        raise HTTPException(404, "Job not found")
    j = jobs[req.job_id]
    if j["status"] != "completed":
        raise HTTPException(400, "Analysis not complete yet")

    transcript = j.get("transcript", "")
    analysis   = j.get("analysis", {})
    context = f"""VIDEO: {j.get('metadata',{}).get('filename','unknown')}
SUMMARY: {analysis.get('short_summary','')}
KEY POINTS: {json.dumps(analysis.get('key_points',[]))}
TOPICS: {', '.join(analysis.get('topics',[]))}

TRANSCRIPT (first 6000 chars):
{transcript[:6000]}"""

    answer = claude_generate(
        f"Context:\n{context}\n\nQuestion: {req.question}\n\nAnswer concisely, referencing specific timestamps where relevant.",
        system="You are VideoIQ, answering questions about a video based on its transcript. Be specific and cite timestamps (MM:SS format) when possible.",
        max_tokens=800,
    )
    return {"answer": answer, "question": req.question}

@app.get("/api/download/{job_id}/{fmt}")
def download_results(job_id: str, fmt: str):
    if job_id not in jobs or jobs[job_id]["status"] != "completed":
        raise HTTPException(404, "Results not available")
    out_dir = Path(jobs[job_id]["output_dir"])
    file_map = {"json": "results.json", "markdown": "insights.md", "txt": "transcript.txt"}
    if fmt not in file_map:
        raise HTTPException(400, "Format must be json, markdown, or txt")
    path = out_dir / file_map[fmt]
    if not path.exists():
        raise HTTPException(404, "File not found")
    return FileResponse(path, filename=path.name)

@app.get("/api/frame/{job_id}/{frame_idx}")
def get_frame(job_id: str, frame_idx: int):
    if job_id not in jobs:
        raise HTTPException(404)
    out_dir    = OUTPUTS_DIR / job_id
    frame_path = out_dir / "frames" / f"frame_{frame_idx:03d}.jpg"
    if not frame_path.exists():
        raise HTTPException(404, "Frame not found")
    return FileResponse(frame_path, media_type="image/jpeg")

@app.get("/api/jobs")
def list_jobs():
    return [
        {"job_id": jid, "filename": j.get("filename"), "status": j["status"],
         "use_case": j.get("use_case"), "created_at": j.get("created_at")}
        for jid, j in sorted(jobs.items(), key=lambda x: x[1].get("created_at",""), reverse=True)
    ]

# ─────────────────────────────────────────────
# SERVE FRONTEND
# ─────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
def serve_ui():
    html_path = STATIC_DIR / "index.html"
    if html_path.exists():
        return HTMLResponse(html_path.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>VideoIQ</h1><p>Frontend not found. Run setup.py first.</p>")

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*50)
    print("  VideoIQ — AI Video Insights Platform")
    print("="*50)
    if not ANTHROPIC_API_KEY:
        print("  ⚠  ANTHROPIC_API_KEY not set — AI features disabled")
        print("     Add it to .env to enable full AI analysis")
    print("  → Open: http://localhost:8000")
    print("="*50 + "\n")
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=False)
