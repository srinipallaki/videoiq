#!/usr/bin/env python3
"""
VideoIQ — Setup & Launch Script
Run this once to check everything, then it starts the server.
"""

import sys
import os
import subprocess
import shutil
from pathlib import Path

ROOT = Path(__file__).parent

def check(condition, ok_msg, fail_msg, fatal=True):
    if condition:
        print(f"  ✅  {ok_msg}")
        return True
    else:
        print(f"  {'❌' if fatal else '⚠️ '}  {fail_msg}")
        if fatal:
            sys.exit(1)
        return False

def run(cmd, **kwargs):
    return subprocess.run(cmd, shell=True, **kwargs)

print()
print("╔═══════════════════════════════════════════╗")
print("║   VideoIQ — AI Video Insights Platform    ║")
print("║   Setup & Launch                          ║")
print("╚═══════════════════════════════════════════╝")
print()

# ── Python version ──────────────────────────────────
print("─── Checking environment ───────────────────")
v = sys.version_info
check(v >= (3, 9), f"Python {v.major}.{v.minor} ✓", f"Python 3.9+ required, found {v.major}.{v.minor}")

# ── FFmpeg ──────────────────────────────────────────
check(shutil.which("ffmpeg") is not None,
      "FFmpeg found",
      "FFmpeg not found.\n"
      "     macOS: brew install ffmpeg\n"
      "     Ubuntu: sudo apt install ffmpeg\n"
      "     Windows: https://ffmpeg.org/download.html  (add to PATH)")

# ── .env file ───────────────────────────────────────
env_path = ROOT / ".env"
if not env_path.exists():
    example = ROOT / ".env.example"
    if example.exists():
        import shutil as sh
        sh.copy(example, env_path)
        print("  ℹ️   Created .env from .env.example")
    else:
        env_path.write_text("ANTHROPIC_API_KEY=\nWHISPER_MODEL=base\n")
        print("  ℹ️   Created blank .env")
else:
    print("  ✅  .env found")

# ── Read .env ───────────────────────────────────────
api_key = ""
for line in env_path.read_text().splitlines():
    line = line.strip()
    if line.startswith("ANTHROPIC_API_KEY="):
        api_key = line.split("=", 1)[1].strip().strip('"').strip("'")

if api_key and api_key not in ("", "sk-ant-...your-key-here..."):
    print("  ✅  ANTHROPIC_API_KEY configured")
else:
    print("  ⚠️   ANTHROPIC_API_KEY not set → AI summaries disabled")
    print("       Edit .env and add your key from https://console.anthropic.com")

# ── Install Python packages ──────────────────────────
print()
print("─── Installing Python packages ─────────────")
req_file = ROOT / "requirements.txt"
result = run(f'"{sys.executable}" -m pip install -r "{req_file}" -q')
if result.returncode == 0:
    print("  ✅  All packages installed")
else:
    print("  ❌  pip install failed — check your internet connection and try manually:")
    print(f"      pip install -r {req_file}")
    sys.exit(1)

# ── Pre-download Whisper model ────────────────────────
print()
print("─── Pre-loading Whisper model ───────────────")
whisper_size = "base"
for line in env_path.read_text().splitlines():
    if line.startswith("WHISPER_MODEL="):
        whisper_size = line.split("=",1)[1].strip().strip('"').strip("'") or "base"

print(f"  ⏳  Loading whisper '{whisper_size}' model (downloads on first run, ~140 MB for base)…")
result = run(f'"{sys.executable}" -c "import whisper; whisper.load_model(\'{whisper_size}\')"',
             capture_output=True)
if result.returncode == 0:
    print(f"  ✅  Whisper '{whisper_size}' ready")
else:
    print(f"  ⚠️   Could not pre-load Whisper (will load on first use): {result.stderr.decode()[:120]}")

# ── Create directories ───────────────────────────────
for d in ["uploads", "outputs", "temp", "static"]:
    (ROOT / d).mkdir(exist_ok=True)
print()
print("─── Directories ready ───────────────────────")
print("  ✅  uploads / outputs / temp / static")

# ── Launch ───────────────────────────────────────────
print()
print("╔═══════════════════════════════════════════╗")
print("║   🚀  Starting VideoIQ server…            ║")
print("║   Open  http://localhost:8000             ║")
print("║   Press Ctrl+C to stop                   ║")
print("╚═══════════════════════════════════════════╝")
print()

os.chdir(ROOT)
os.execv(sys.executable, [sys.executable, "-m", "uvicorn", "app:app",
                           "--host", "0.0.0.0", "--port", "8000",
                           "--reload", "--reload-dir", str(ROOT)])
